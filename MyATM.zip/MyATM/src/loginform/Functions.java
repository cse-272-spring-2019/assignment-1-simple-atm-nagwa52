/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginform;

import java.util.Stack;
import static loginform.Deposite.deposit;
import static loginform.Withdraw.amount;

/**
 *
 * @author user
 */
public class Functions {

    public  float balance = 0;
    public  float deposite = 0;
    public  float amount = 0;
  String insuff= " You have insufficient funds";
  int count=0;
 //String suff = "\"You have withdrawn \"+amount+\" and your new balance is \"+balance+\"";
    Stack<Float> stack = new Stack<>();
   
    float array[];

    public  float getBalance() {

        return balance;
    }

    public  float getDeposite() {
        if ((balance + deposit) >= 0) {

            balance = deposit + balance;
        }
        return balance;
    }

    

        // Loop over int values.
   

public String getWithdraw(){
      if(amount > balance || amount == 0){
          
                  return insuff;
                 
                   // anotherTransaction(); 
                } else {
                    
                    balance = balance - amount;
                    count++;
                   String balan =Float.toString(balance);
                    return balan;
                   
                  //  anotherTransaction(); 
                  
                }
    }  
public Float getHistory(float balan){
     balan=this.balance;
     float array[] = new float[5]; 
   
      for(int i=0;i<=count;i++){
    stack.push(balan);
}
      for(int j =0;j<array.length;j++){
        array [j]= stack.pop();
   
    }
return balan;
}
            
      
     /* double currentBalance;

	double amountNumber;

	String status;

	
      BalanceInquiry balinq;
      public Label myLabel;
	//BankAccount bankAccount;
public void setLabelText(String txt)
{
     label.setText(txt);
}
balinq.setLabelText("Sent from another class");
	

	public void getCurrentBalance(double balanceValue)

	{

		currentBalance = balanceValue;

	}

	

	public double deposit(double amountValue)

	{

		amountNumber = amountValue;

		currentBalance = currentBalance + amountNumber;

		setCurrentBalance();

	}

	

	public double withdraw(double amountValue)

	{

		amountNumber = amountValue;

		currentBalance = currentBalance - amountNumber;

		if(currentBalance < 0)

		{

			status = "Overdrawn";

			balinq.amountlbl.setText(status);

		}

		else

		{

			status = "OK";

			setCurrentBalance();

		}

	}

	

	public void setCurrentBalance()

	{

		balinq.statusJTextField.setText(status);

		bankAccount.balanceJTextField.setText(currentBalance);

		bankAccount.amountJTextField.setText("");

		bankAccount.amountJTextField.requestFocusInWindow();

	}

}
 */
}
